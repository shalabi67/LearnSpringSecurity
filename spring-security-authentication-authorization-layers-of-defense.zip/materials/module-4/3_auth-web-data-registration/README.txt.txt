You will need to register a new user to login to the site:
http://localhost:8080/register