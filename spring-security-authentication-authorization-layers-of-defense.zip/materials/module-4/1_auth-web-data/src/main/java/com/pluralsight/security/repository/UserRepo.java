package com.pluralsight.security.repository;

public class UserRepo {

}
