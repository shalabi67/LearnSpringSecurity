Spring will configure a defeault user
username: user
password will be printed in the log each time the application starts.